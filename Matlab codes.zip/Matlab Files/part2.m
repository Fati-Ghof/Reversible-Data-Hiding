%we have used two maxes and two zeros for shifting histigram
clc
clear all
I1=imread('ch01 Introduction.bmp');
I=(rgb2gray(I1));
[m,n]=size(I);
wm1=imread('logo.JPG');
wm2=rgb2gray(wm1);
level = graythresh(wm2);
wm= im2bw(wm2,level); 
figure
imhist(I)
title('Histogram of orginal image')
[y,x]=imhist(I);
[max,x1]=max(y);
q=[y,x];
s=sortrows(q,2);
    for i=1:m
        for j=1:n
           if I(i,j)>=x1
                Ish(i,j)=I(i,j)+1;
            else
                Ish(i,j)=I(i,j);
            end
        end
    end
    for i=1:256
        if s(i,1)>(4096-max)
            x2=s(i,2);
            break
        end
    end
   for i=1:m
       for j=1:n
           if I(i,j)<x2
               Ish(i,j)=I(i,j)-1;
           end
       end
   end
figure
imhist(Ish)
title('shifted histogram')

k=1;
l=1;
for i=1:m
    for j=1:n
        if Ish(i,j)==x1-1
           r(k,1)=i;
           h(l,1)=j;
           k=k+1;
           l=l+1;
        end
    end
end
k=1;
l=1;
for i=1:m
    for j=1:n
        if Ish(i,j)==x2
           u(k,1)=i;
           v(l,1)=j;
           k=k+1;
           l=l+1;
       end
    end
end
a=1;
b=1;
for i=1:43
    for j=1:64
        if wm(i,j)==1
            Ish(r(a,1),h(b,1))=x1;
        end
        a=a+1;
        b=b+1;
    end
end
a=1;
b=1;
for i=44:64
    for j=1:64
        if wm(i,j)==1
            Ish(u(a,1),v(b,1))=x2-1;
        end
        a=a+1;
        b=b+1;
    end
end
figure
imhist(Ish)
title('histogram of embedded image')
figure
imshow(Ish)
title('embedded image')
% Calculating PSNR
mseimage=(double(I)-double(Ish)).^2;
mse=sum(sum(mseimage))/(512*512);
PSNRwmimg=10*log10(255^2/mse)

%Extraction
z=1;

for i=1:m
    for j=1:n
        if Ish(i,j)==x1
            ex(z,1)=i;
            ey(z,1)=j;
            ez(z,1)=1;
            z=z+1;
        end
            if Ish(i,j)==x1-1
            ex(z,1)=i;
            ey(z,1)=j;
            ez(z,1)=0;
            z=z+1;
            end
        end
end

em=[ex,ey,ez];
ss=sortrows(em,1);
f=1;
for i=1:43
    for j=1:64
        ewm(i,j)=ss(f,3);
        f=f+1;
    end
end

z=1;
for i=1:m
    for j=1:n
        if Ish(i,j)==x2
            ex1(z,1)=i;
            ey1(z,1)=j;
            ez1(z,1)=0;
            z=z+1;
        end
            if Ish(i,j)==x2-1
            ex1(z,1)=i;
            ey1(z,1)=j;
            ez1(z,1)=1;
            z=z+1;
            end
        end
end

em1=[ex1,ey1,ez1];
ss1=sortrows(em1,1);
f=1;
for i=44:64
    for j=1:64
        ewm(i,j)=ss1(f,3);
        f=f+1;
    end
end
figure
imshow(ewm)
title('extracted wm')

dd=wm-ewm;
figure
imshow(dd)
title('diffrence of extracted wm & original wm')
        
