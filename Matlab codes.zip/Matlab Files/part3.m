
clc
clear all
I1=imread('ch01 Introduction.bmp');
I=(rgb2gray(I1));
[m,n]=size(I);
wm1=imread('logo.JPG');
wm2=rgb2gray(wm1);
level = graythresh(wm2);
wm= im2bw(wm2,level); 
figure
imhist(I)
title('Histogram of orginal image')
[y,x]=imhist(I);
[max,x1]=max(y);
    for i=1:m
        for j=1:n
            if I(i,j)>=x1
                Ish(i,j)=I(i,j)+1;
            else
                Ish(i,j)=I(i,j);
            end
        end
    end
figure
imhist(Ish)
k=1;
l=1;
for i=1:m
    for j=1:n
        if Ish(i,j)==x1-1
           r(k,1)=i;
           s(l,1)=j;
           k=k+1;
           l=l+1;
        end
    end
end
p=[r,s];
a=1;
b=1;
for i=1:43
    for j=1:64
        if wm(i,j)==1
            Ish(r(a,1),s(b,1))=x1;
        end
        a=a+1;
        b=b+1;
    end
end
figure
imhist(Ish)
title('shifted histogram after the first embedding')
[z,o]=imhist(Ish);
q=[z,o];
s=sortrows(q);
    for i=1:m
        for j=1:n
            if Ish(i,j)>s(256,2)
                Ishp(i,j)=Ish(i,j)+1;
            else
                Ishp(i,j)=Ish(i,j);
            end
        end
    end
figure
imhist(Ishp)
k=1;
l=1;
for i=1:m
    for j=1:n
        if Ishp(i,j)==s(256,2)
           rp(k,1)=i;
           sp(l,1)=j;
           k=k+1;
           l=l+1;
        end
    end
end

a=1;
b=1;
for i=44:64
    for j=1:64
        if wm(i,j)==1
            Ishp(rp(a,1),sp(b,1))=s(256,2)+1;
        end
        a=a+1;
        b=b+1;
    end
end
figure
imhist(Ishp)
title('shifted histogram after the second embedding')


figure
imshow(Ishp)
% Calculating PSNR
mseimage=(double(I)-double(Ishp)).^2;
mse=sum(sum(mseimage))/(512*512);
PSNRwmimg=10*log10(255^2/mse)
%Extraction
ewm1=zeros(64,64);
ewm2=zeros(64,64);

z=1;
for i=1:m
    for j=1:n
        if Ishp(i,j)==s(256,2)
            ex1(z,1)=i;
            ey1(z,1)=j;
            ez1(z,1)=0;
            z=z+1;
        end
            if Ishp(i,j)==s(256,2)+1
            ex1(z,1)=i;
            ey1(z,1)=j;
            ez1(z,1)=1;
            z=z+1;
            end
        end
end

em1=[ex1,ey1,ez1];
ss1=sortrows(em1,1);
f=1;
for i=44:64
    for j=1:64
        ewm2(i,j)=ss1(f,3);
        f=f+1;
    end
end
figure
imshow(ewm2)

dd=wm-ewm2;
figure
imshow(dd)

z=1;

for i=1:m
    for j=1:n
        if Ish(i,j)==x1
            ex(z,1)=i;
            ey(z,1)=j;
            ez(z,1)=1;
            z=z+1;
        end
            if Ish(i,j)==x1-1
            ex(z,1)=i;
            ey(z,1)=j;
            ez(z,1)=0;
            z=z+1;
            end
        end
end

em=[ex,ey,ez];
ss=sortrows(em,1);
f=1;
for i=1:43
    for j=1:64
        ewm1(i,j)=ss(f,3);
        f=f+1;
    end
end

figure
imshow(ewm1)

ddd=wm-ewm1;
figure
imshow(ddd)

ewm=ewm1+ewm2;
figure
imshow(ewm)
title('extracted wm')
dn=wm-ewm;
figure
imshow(dn)
title('diffrence of extracted wm & original wm')



        
    
    